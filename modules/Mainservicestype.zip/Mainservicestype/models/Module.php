<?php

class Mainservicestype_Module_Model extends Vtiger_Module_Model {
    
    public function isQuickCreateSupported(){
                 return true;
}
    }
?>
